from .autoinstaller import AutoInstaller
from .loadings import printr, Loading
from .photo import Photo
from .switch import switch
